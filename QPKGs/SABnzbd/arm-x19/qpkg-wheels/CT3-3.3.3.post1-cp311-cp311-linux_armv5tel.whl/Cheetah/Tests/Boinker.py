from __future__ import absolute_import

from Cheetah.Template import Template


class Boinker(Template):
    def boink(self):
        return [1, 2, 3]
