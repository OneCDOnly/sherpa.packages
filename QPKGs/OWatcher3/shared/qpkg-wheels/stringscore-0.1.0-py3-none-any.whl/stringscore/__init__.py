"""
String Score
~~~~~~~~~~~~

An algorithm provides scores between 0.0 (no match) to 1.0 (perfect match) for a comparison of two strings.

:copyright: (c) 2013 by Grey Lee.
:license: MIT License.
"""

__version__ = '1.0'
__author__ = 'Grey Lee <bcse@bcse.tw>'
